package com.cg.payroll.stepdefination;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PayrollStepDefination {
	@Given("^User is on Payroll Home Page$")
	public void user_is_on_Payroll_Home_Page() throws Throwable {
	
	}

	@When("^User clicks on 'Sign In'$")
	public void user_clicks_on_Sign_In() throws Throwable {
	    
	}

	@Then("^Link should display with 'Sign In'$")
	public void link_should_display_with_Sign_In() throws Throwable {
	   
	}

	@When("^User clicks on 'Sign Up'$")
	public void user_clicks_on_Sign_Up() throws Throwable {
	    
	}

	@Then("^Link should display with 'Sign Up'$")
	public void link_should_display_with_Sign_Up() throws Throwable {
	    
	}
}
