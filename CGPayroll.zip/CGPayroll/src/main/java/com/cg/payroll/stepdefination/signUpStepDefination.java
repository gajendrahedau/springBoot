package com.cg.payroll.stepdefination;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class signUpStepDefination {
	@Given("^User is on Payroll Signup Page$")
	public void user_is_on_Payroll_Signup_Page() throws Throwable {

	}

	@When("^User submits correct details$")
	public void user_submits_correct_details() throws Throwable {
	    
	}

	@Then("^Register the user$")
	public void register_the_user() throws Throwable {
	    
	}

	@Given("^User is on Payroll SignUp Page$")
	public void user_is_on_Payroll_SignUp_Page() throws Throwable {
	    
	}

	@When("^User submits his incorrect details$")
	public void user_submits_his_incorrect_details() throws Throwable {
	    
	}

	@Then("^Display the error to user$")
	public void display_the_error_to_user() throws Throwable {
	   
	}

	@Then("^Ask user to try again$")
	public void ask_user_to_try_again() throws Throwable {
	    
	}
}
