package com.cg.payroll.stepdefination;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class signInStepDefination {
	@Given("^User is on Payroll Signin Page$")
	public void user_is_on_Payroll_Signin_Page() throws Throwable {
	    
	}

	@When("^User submit correct details$")
	public void user_submit_correct_details() throws Throwable {
	  
	}

	@Then("^User logs in$")
	public void user_logs_in() throws Throwable {
	
	}

	@Given("^User is on Payroll SignIn Page$")
	public void user_is_on_Payroll_SignIn_Page() throws Throwable {
	  
	}

	@When("^User submits  incorrect details$")
	public void user_submits_incorrect_details() throws Throwable {
	  
	}

	@Then("^Display the errors to user$")
	public void display_the_errors_to_user() throws Throwable {
	  
	}

	@Then("^Ask user to login again$")
	public void ask_user_to_login_again() throws Throwable {
	   
	}
}
