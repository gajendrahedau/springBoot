package com.cg.onlineshop.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgOnlineShopSpringRestJpaDataBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgOnlineShopSpringRestJpaDataBootApplication.class, args);
	}
}
